from libqtile import bar, layout, widget, extension, hook
from libqtile.config import Click, Drag, Group, Key, Match, Screen
from libqtile.lazy import lazy
from libqtile.utils import guess_terminal
import os, subprocess

mod = "mod4" #Win 
terminal = guess_terminal()

keys = [
    # Window Managing
    # Switch between windows
    Key([mod], "h", lazy.layout.left(), desc="Move focus to left"),
    Key([mod], "l", lazy.layout.right(), desc="Move focus to right"),
    Key([mod], "j", lazy.layout.down(), desc="Move focus down"),
    Key([mod], "k", lazy.layout.up(), desc="Move focus up"),
    Key([mod], "space", lazy.layout.next(), desc="Move window focus to other window"),
    # Move windows between left/right columns or move up/down in current stack.
    Key([mod, "shift"], "h", lazy.layout.shuffle_left(), desc="Move window to the left"),
    Key([mod, "shift"], "l", lazy.layout.shuffle_right(), desc="Move window to the right"),
    Key([mod, "shift"], "j", lazy.layout.shuffle_down(), desc="Move window down"),
    Key([mod, "shift"], "k", lazy.layout.shuffle_up(), desc="Move window up"),
    # Grow windows. If current window is on the edge of screen and direction
    Key([mod, "control"], "h", lazy.layout.grow_left(), desc="Grow window to the left"),
    Key([mod, "control"], "l", lazy.layout.grow_right(), desc="Grow window to the right"),
    Key([mod, "control"], "j", lazy.layout.grow_down(), desc="Grow window down"),
    Key([mod, "control"], "k", lazy.layout.grow_up(), desc="Grow window up"),
    Key([mod], "n", lazy.layout.normalize(), desc="Reset all window sizes"),
    Key(
        [mod, "shift"],
        "Return",
        lazy.layout.toggle_split(),
        desc="Toggle between split and unsplit sides of stack",
    ),
    Key([mod], "Return", lazy.spawn(terminal), desc="Launch terminal"),
    Key([mod], "w", lazy.window.kill(), desc="Kill focused window"),
    Key([mod, "control"], "r", lazy.reload_config(), desc="Reload the config"),
    Key([mod, "control"], "q", lazy.shutdown(), desc="Shutdown Qtile"),
]

groups = [
    Group("  "),
    Group(""),
    Group(" ")

        ]

layouts = [
    layout.Columns(
        border_focus="#81c8be",
        border_focus_stack="#85c1dc",
        border_normal="#cdd6f4",
        border_on_single=True,
        border_width=3,
        margin=[2,8,2,8],
        margin_on_single=[20,30,30,30]
    )]

widget_defaults = dict(
    font='Inconsolata Bold Nerd Font Complete Mono',
    fontsize=16,
    padding=3,
)
extension_defaults = widget_defaults.copy()

screens = [
    Screen(
        top=bar.Bar(
            [   
                widget.Spacer(length=10),
                widget.Image(
                    filename="~/.config/pic/nix.png",
                    mouse_callbacks={'Button1':lazy.spawn("rofi -show drun -theme ~/.config/rofi/style-7.rasi")}
                ),
                widget.GroupBox(
                    active="#f2cdcd",
                    block_highlight_text_color="#94e2d5",
                    fontsize=26,
                    padding=1,
                    borderwidth=0,
                ),
                widget.Spacer(),
                widget.Systray(),
                widget.KeyboardLayout(
                    configured_keyboards=["us","ir"],
                    foreground="#cdd6f4",
                    fontsize=22

                ),
                widget.WidgetBox(widgets=[
                    widget.Memory(
                        foreground="#f2cdcd",
                        format='{MemUsed: .0f}{mm}  ',
                        measure_mem="G",
                    ),
                    widget.Load(
                        foreground="#f2cdcd",
                        format='{time}: {load:.1f} 勒  ',
                    ),
                    widget.DF(),
                    ],
                    fontsize=22,
                    foreground="#fab387",
                    text_closed="    ",
                    text_open="   ",
                ),
                widget.WidgetBox(widgets=[
                     widget.Wttr(
                         location={"Marand":" "}, 
                         fontsize=22,
                         foreground="#89dceb"
                     ),
                     ],
                    fontsize=22,
                    foreground="#a6e3a1",
                    text_closed="  " ,
                    text_open=" 煮 "
                ),
                widget.Clock(
                    fontsize=22,
                    font="Inconsolata Bold Nerd Font Complete Mono",
                    foreground="#c6a0f6",
                    format=" %H:%M",
                ),
                widget.WidgetBox(widgets=[
                    widget.Image(
                        filename="~/.config/pic/power.png",
                        margin=2,
                        mouse_callbacks={'Button1':lazy.spawn("shutdown -h now")}
                    ),
                    widget.Image(
                        filename="~/.config/pic/restart.png",
                        margin=5,
                        mouse_callbacks={'Button1':lazy.spawn("reboot")}
                    ),
                    
                    ],
                    fontsize=22,
                    foreground="#f38ba8",
                    text_closed="   ",
                    text_open="   ",
                )
            ],
            35,
            margin=[8,8,8,8],
            background="#1e2030"
        ),
        wallpaper_mode="fill",
        wallpaper="~/.config/pic/bg.jpg",
    ),
    ]

# Drag floating layouts.
mouse = [
    Drag([mod], "Button1", lazy.window.set_position_floating(), start=lazy.window.get_position()),
    Drag([mod], "Button3", lazy.window.set_size_floating(), start=lazy.window.get_size()),
    Click([mod], "Button2", lazy.window.bring_to_front()),
]


dgroups_key_binder = None
dgroups_app_rules = []  # type: list
follow_mouse_focus = True
bring_front_click = False
cursor_warp = False
floating_layout = layout.Floating(
    float_rules=[
        # Run the utility of `xprop` to see the wm class and name of an X client.
        *layout.Floating.default_float_rules,
        Match(wm_class="confirmreset"),  # gitk
        Match(wm_class="makebranch"),  # gitk
        Match(wm_class="maketag"),  # gitk
        Match(wm_class="ssh-askpass"),  # ssh-askpass
        Match(title="branchdialog"),  # gitk
        Match(title="pinentry"),  # GPG key password entry
    ]
)


auto_fullscreen = True
focus_on_window_activation = "smart"
reconfigure_screens = True
auto_minimize = True
wmname = "QtiLE"

#startup
@hook.subscribe.startup_once
def autostart():
    os.system("bash /home/amir/.config/start.sh")
